//package com.Stream.Demo
//
//import org.apache.spark.sql.SparkSession
//import org.apache.spark.sql.functions.expr
//
//object SparkStreamingSaveToFile {
//  def main(args: Array[String]): Unit = {
//
//    //  Step 1: Create SparkSession
//    // SparkSession is the entry point for Structured Streaming
//    val spark = SparkSession.builder()
//      .master("local[3]")                          // Use 3 local threads
//      .appName("ScalaStreamingDemo")               // Application name
//      .config("spark.streaming.stopGracefullyOnShutdown", "true") // Graceful shutdown
//      .config("spark.sql.shuffle.partitions", 3)   // Parallelism for shuffle operations
//      .getOrCreate()
//
//    //  Step 2: Read stream data from a socket
//    // Spark Structured Streaming listens to a socket on localhost:9999
//    // Run in terminal: `nc -lk 9999` (to send text data to the stream)
//    val lineDF = spark.readStream
//      .format("socket")
//      .option("host", "localhost")   // Hostname
//      .option("port", "9999")        // Port number
//      .load()
//
//    //  Step 3: Split lines into words
//    // 1. 'split(value, " ")' → splits each line by space
//    // 2. 'explode' → converts array of words into multiple rows
//    val wordDF = lineDF.select(expr("explode(split(value,' ')) as word"))
//
//    //  Step 4: Group by words and count occurrences
//    val countDF = wordDF.groupBy("word").count()
//
//    //  Step 5: Define query (sink) to write streaming output
//    val query = countDF.writeStream
//      .format("console")  // Output to console (for demo)
//      .option("checkpointLocation", "chk-point-dir") // Store metadata for recovery
//      .option("truncate", "false") // Do not truncate long column values
//      .option("numRows", 50)       // Show max 50 rows
//      .outputMode("complete")      // "complete" mode shows full table on each trigger
//      .start()
//
//    //  Step 6: Print schema for debugging
//    countDF.printSchema()
//
//    //  Step 7: Keep the query running until terminated
//    query.awaitTermination()
//  }
//}
