package com.Stream.Demo
package com.Stream.Demo

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.expr

object StreamingWC {
def main(args: Array[String]): Unit={
  val spark = SparkSession.builder()
    .master("local[3]")
    .appName("ScalaStreamingDemo")
    .config("spark.streaming.stopGracefullyOnShutdown","true")
    .config("spark.sql.shuffle.partitions",3)
    .getOrCreate()

  //Reading the file stream
  //Transform the file
  //Output the file
  val lineDF = spark.readStream
    .format("socket")
    .option("host","localhost")
    .option("port","9999")
    .load()

  val wordDF = lineDF.select(expr("explode(split(value,' ')) as word"))
  val countDF = wordDF.groupBy("word").count()
  val query = countDF.writeStream
    .format("console")
    .option("checkpointLocation", "chk-point-dir")
    .option("truncate", "false")
    .option("numRows",50)
    .outputMode("complete") //or Append
    .start()

  countDF.printSchema()

  query.awaitTermination()


}
}

