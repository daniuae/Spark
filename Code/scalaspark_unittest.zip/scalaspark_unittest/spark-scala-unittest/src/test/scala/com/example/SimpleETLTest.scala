package com.example

import org.apache.spark.sql.SparkSession
import org.scalatest.funsuite.AnyFunSuite

class SimpleETLTest extends AnyFunSuite {
  val spark = SparkSession.builder()
    .appName("SimpleETLTest")
    .master("local[*]")
    .getOrCreate()

  import spark.implicits._

  test("transformData should filter out people age <= 25") {
    val df = Seq(("Alice", 30), ("Bob", 20), ("Charlie", 40)).toDF("name", "age")
    val result = SimpleETL.transformData(df).collect()
    assert(result.length == 2)
  }
}
