package com.example

import org.apache.spark.sql.{DataFrame, SparkSession}

object SimpleETL {
  def transformData(df: DataFrame): DataFrame = {
    df.filter("age > 25")
  }

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("SimpleETL")
      .master("local[*]")
      .getOrCreate()

    import spark.implicits._
    val data = Seq(("Alice", 30), ("Bob", 20), ("Charlie", 40))
    val df = data.toDF("name", "age")

    transformData(df).show()

    spark.stop()
  }
}
